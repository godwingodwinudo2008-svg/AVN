# AVN — Complete MVP

This is a real full-stack starter, not only a static page.

## Included
- AVN mobile-first website/PWA
- Student registration and login
- SQLite database
- Course catalog
- Purchase records
- Paystack payment initialization + verification
- Admin role and admin API endpoints
- PWA manifest + service worker

## Before production
1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET`.
3. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
4. Add your Paystack secret key to `PAYSTACK_SECRET_KEY`.
5. Set `APP_URL` to the HTTPS URL where AVN is hosted.
6. Run `npm install`, then `npm start`.

IMPORTANT: Never put the Paystack secret key in browser code. Paystack says secret keys belong on the backend and must be stored securely. Use test keys while developing, then switch to live keys only when ready.

The current courses are ₦6,000 and ₦20,000, represented in the database as kobo.

For a production launch, add:
- HTTPS hosting/domain
- Paystack webhook endpoint and signature validation
- stronger admin UI
- lesson/video management UI
- password reset/email verification
- privacy/terms pages
- backups and monitoring
- referral commission rules and payout workflow


## OPay manual payment mode
Customers pay the displayed OPay account, submit their transaction/reference number, and an AVN admin manually approves or rejects the purchase. This is intentionally manual because your current OPay account does not expose the Business/API dashboard needed for automatic verification. OPay documents Business API/webhook integrations for accounts with those capabilities enabled. 


## Full AVN Curriculum
The Affiliate Marketing Training course now includes six structured modules: Affiliate Foundation; Audience & Content; Promotion Strategy; Tools & AI; Conversion Basics; Execution & Consistency. Each module contains eight lessons, a practical assignment, and a checkpoint question.
