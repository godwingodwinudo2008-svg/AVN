require("dotenv").config();
const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");

const app = express();
const db = new Database("avn.db");
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "development-only-change-me";

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, phone TEXT,
 password_hash TEXT NOT NULL, role TEXT DEFAULT 'student', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS courses(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, description TEXT NOT NULL, price INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS purchases(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL, course_id INTEGER NOT NULL, reference TEXT UNIQUE,
 status TEXT DEFAULT 'pending', amount INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS lessons(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 course_id INTEGER NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL, position INTEGER DEFAULT 1
);
`);

// Extended curriculum fields. Existing databases are upgraded safely.
try { db.exec("ALTER TABLE lessons ADD COLUMN module TEXT DEFAULT 'Affiliate Foundation'"); } catch(e) {}
try { db.exec("ALTER TABLE lessons ADD COLUMN assignment TEXT DEFAULT ''"); } catch(e) {}
try { db.exec("ALTER TABLE lessons ADD COLUMN quiz TEXT DEFAULT ''"); } catch(e) {}

const curriculum = [
["A. Affiliate Foundation", [
["What Affiliate Marketing Really Is","Affiliate marketing is a performance-based business model where a person or company recommends a product or service using a trackable affiliate link. When a qualifying action happens, the affiliate may receive a commission according to the program's terms. The core skill is not simply dropping links; it is matching a real audience problem with a legitimate solution and communicating that solution clearly.","Write a three-sentence explanation of affiliate marketing in your own words.","What is the main purpose of an affiliate link? | To track qualifying referrals | To hide the product | To guarantee a sale | To replace customer support"],
["The Affiliate Ecosystem","The basic ecosystem has four important roles: the merchant or product owner, the affiliate, the customer, and sometimes an affiliate network or tracking platform. The merchant supplies the offer. The affiliate creates promotion. The customer makes the purchase or completes another qualifying action. The network or merchant records attribution and handles commission rules.","Draw the four roles and show the direction of value between them.","Who ultimately decides the commission rules? | The merchant or affiliate program | The customer | The affiliate's phone | The social platform"],
["How Tracking and Commissions Work","Affiliate links usually contain identifiers that help a program attribute a click or conversion to an affiliate. Programs can pay per sale, lead, signup, click, or another defined action. Always read the specific program's terms because attribution windows, eligible products, refunds, and payout thresholds vary.","Choose one affiliate program you may use and list its commission and payout rules after reading its terms.","Why are tracking identifiers important? | They help attribute qualifying actions | They guarantee conversions | They increase product quality | They replace a niche"],
["Choosing a Profitable Niche","A useful niche sits where audience demand, legitimate offers, and your ability to create useful content overlap. Look for recurring problems people actively seek solutions for. Avoid choosing a niche only because someone claims it is profitable. Sustainable affiliate work requires enough problems, products, questions, and content angles to keep serving the audience.","List three possible niches and score each from 1–5 for demand, product availability, content potential, and your willingness to learn.","What should you avoid using as the only reason to choose a niche? | A high commission claim | Audience demand | Product fit | Content potential"],
["Understanding Your Audience","Audience research means understanding who you want to help, what they are trying to achieve, what frustrates them, and what they already do to solve the problem. A clear audience makes content and offers more specific. You do not need to target everyone; you need a useful message for a defined group.","Complete: My audience is ___. They struggle with ___. They want ___. They currently try ___.","What makes a marketing message more useful? | Relevance to a defined audience | Talking to everyone at once | Using more jargon | Hiding the problem"],
["Selecting the Right Offer","A good offer should solve a real problem for your audience and come from a legitimate source. Check product quality, refund policy, affiliate rules, commission terms, brand reputation, and whether your claims can be supported. A high commission is not a good reason to promote a poor product.","Create a five-point offer checklist you will use before promoting any product.","Which should come first when selecting an offer? | Product and audience fit | Highest commission | Most dramatic promise | Shortest sales page"],
["The Affiliate Business Model","A simple affiliate system is Audience → Valuable Content → Attention → Trust → Offer → Conversion → Follow-up. Each stage has a job. Content earns attention; useful communication builds trust; the offer gives a relevant next step; follow-up helps people make an informed decision. This model is more durable than posting links randomly.","Map your chosen niche through all seven stages and write one action for each stage.","What should valuable content do before asking for a sale? | Help the audience understand or solve something | Hide the offer | Promise guaranteed income | Ignore the audience"],
["Your First Affiliate Setup","Start with one niche, one audience, and one legitimate offer. Read the affiliate program rules, create or obtain your tracking link, choose one main channel, and create a simple content plan. Keep your first system small enough to execute and measure.","Write your first setup: niche, audience, offer, channel, first content idea, and first action within 24 hours.","What is a sensible first setup? | One focused audience and offer | Ten unrelated niches | Every platform at once | No tracking"],
]],
["B. Audience & Content", [
["Content Starts With a Problem","Strong affiliate content begins with an audience problem, question, goal, or decision. Before creating a post, ask: what does my audience need to understand or do? Useful content can educate, compare, demonstrate, explain, or help someone avoid a mistake.","Write ten real questions your audience could ask about your niche.","What is a strong starting point for content? | A real audience problem | A random product link | A copied caption | A guaranteed income claim"],
["Finding Audience Questions","Use customer reviews, community discussions, search suggestions, FAQs, comments, and conversations to discover recurring questions. Group them into themes such as beginner questions, comparisons, mistakes, tools, costs, and implementation.","Collect 20 audience questions and group them into five themes.","Why collect audience questions? | To discover useful content topics | To guarantee sales | To avoid research | To replace a product"],
["Educational Content","Educational content teaches something specific. Good educational posts have one clear outcome, simple language, an example, and a practical next step. Avoid stuffing one post with everything you know.","Create a short lesson that teaches one beginner concept in your niche.","What makes educational content clearer? | One specific outcome | Ten unrelated topics | More jargon | No example"],
["Trust-Building Content","Trust grows when your content is useful, honest, consistent, and transparent. Explain what you know, acknowledge what you do not know, disclose affiliate relationships when appropriate, and avoid fabricated testimonials or results.","Write three trust-building content ideas: a lesson, a personal learning story, and a transparent product review.","Which damages trust most? | Fabricated results or testimonials | Clear explanations | Honest limitations | Useful examples"],
["Hooks and Attention","A hook earns the first few seconds of attention. Effective hooks can name a problem, challenge an assumption, promise a useful lesson, or ask a specific question. The hook should match the content; do not use sensational claims the lesson cannot support.","Write five hooks for one topic using five different angles.","What should a good hook do? | Earn relevant attention | Mislead the audience | Guarantee income | Hide the topic"],
["Storytelling for Affiliate Marketing","Stories make concepts memorable when they have context, a problem, a decision, an action, and a lesson. Use real experiences where possible. If you use an example, label it as an example rather than presenting it as a real customer story.","Create a short story outline about a beginner learning one affiliate skill.","What should a story communicate? | A clear lesson or experience | A fake result | An unrelated product | A hidden advertisement"],
["Building a Content Calendar","A simple calendar can rotate educational, problem-solving, comparison, proof-of-work, community, and offer content. Consistency means following a realistic schedule, not posting constantly. Track what topics earn useful engagement and improve them.","Create a seven-day calendar with one useful content idea per day.","What is the purpose of a content calendar? | Consistent, planned communication | Posting without purpose | Guaranteeing virality | Avoiding measurement"],
["Content Assignment: Build Your First Week","Turn your research into seven pieces of content. For each one, define the audience, problem, hook, lesson, call to action, and destination. Review every piece for accuracy and compliance with the platform and affiliate program rules.","Submit your seven-day content plan with seven hooks and seven practical CTAs.","What should you check before publishing affiliate content? | Accuracy and applicable rules | Only the number of emojis | Whether the claim sounds dramatic | Whether it hides the offer"],
]],
["C. Promotion Strategy", [
["Organic Promotion Fundamentals","Organic promotion uses useful content, communities, search, referrals, and consistent communication rather than paying for every impression. The objective is to reach the right people and earn attention over time.","Choose one primary organic channel and explain why your audience uses it.","What is the goal of organic promotion? | Reach relevant people through useful communication | Spam more groups | Guarantee sales | Avoid content"],
["WhatsApp Promotion","WhatsApp can work well for relationship-based marketing when messages are relevant and permission-based. Use status updates, helpful conversations, communities where permitted, and clear next steps. Avoid unsolicited bulk messages and misleading claims.","Create a three-part WhatsApp sequence: teach, demonstrate, invite.","What is a healthier WhatsApp strategy? | Relevant, permission-based communication | Unsolicited spam | Repeated links | Fake urgency"],
["Facebook Promotion","Facebook promotion can include educational posts, videos, communities that allow relevant posts, and a page or profile strategy. Each community has its own rules. Value-first content reduces the temptation to make every post a sales pitch.","Design three Facebook posts: educational, story-based, and offer-related.","What should you do before posting in a group? | Check and follow the group rules | Ignore the rules | Post repeatedly | Hide the commercial intent"],
["Short-Form Content Strategy","Short-form content works when it delivers one clear idea quickly. A simple structure is Hook → Problem → Insight → Example → CTA. Reuse strong topics in multiple formats without copying misleading claims.","Turn one lesson from Module A into a 30–60 second script outline.","What makes short-form content focused? | One clear idea | Many unrelated ideas | No takeaway | Only a sales pitch"],
["Community-Based Marketing","Communities can provide research, feedback, relationships, and qualified attention. Participate before promoting. Answer questions and follow community rules. Never impersonate a customer or manufacture social proof.","Choose two communities where your audience already discusses the problem and write how you will contribute value.","What should come before promotion in a community? | Useful participation | Link dropping | Fake testimonials | Mass messaging"],
["Calls to Action","A call to action tells people what useful next step is available: read a guide, watch a lesson, compare options, request details, or visit an offer. Match the CTA to the audience's readiness.","Write three CTAs: beginner, considering, and ready-to-buy.","What should a CTA do? | Give a clear next step | Pressure everyone equally | Promise guaranteed results | Hide the destination"],
["Building a Simple Promotion Funnel","A basic funnel can be Content → Landing/Information → Offer → Follow-up. The funnel should answer questions at each stage. Measure clicks, leads, conversions, and drop-off points where possible.","Draw your first four-stage funnel and write what the customer sees at each stage.","Why measure funnel stages? | To identify where people drop off | To guarantee conversions | To avoid learning | To hide performance"],
["Promotion Rules and Reputation","Affiliate promotion must respect the affiliate program, advertising platform, consumer-protection requirements, privacy rules, and community policies that apply to you. Avoid false scarcity, fake testimonials, deceptive income claims, and spam.","Create your personal promotion checklist: truth, disclosure, permission, platform rules, affiliate rules.","What protects long-term reputation? | Honest and compliant promotion | Fake urgency | Fabricated proof | Spam"],
]],
["D. Tools & AI", [
["Your Core Affiliate Toolkit","A practical toolkit can include a notes system, spreadsheet, design tool, analytics/tracking, link management where permitted, communication tools, and an AI assistant. Tools should reduce friction rather than become the business itself.","List the tools you already have and identify one gap in your workflow.","What is the purpose of a toolkit? | Make execution easier and measurable | Collect apps | Replace strategy | Guarantee income"],
["AI for Content Ideas","AI can help brainstorm topic clusters, hooks, outlines, questions, and variations. Your job is to provide context, verify claims, and select ideas that genuinely help your audience.","Ask an AI assistant for 20 content ideas for your niche, then keep the best five and explain why.","Who is responsible for the final accuracy of published content? | You, the publisher | The AI tool | The audience | The platform"],
["AI for Research","AI can organize questions and summarize information, but important claims should be checked against reliable primary or official sources. Do not treat an AI-generated statement as proof.","Research one affiliate offer using its official terms and create a fact sheet.","What should you do with important AI-generated claims? | Verify them | Publish automatically | Assume they are true | Remove all sources"],
["AI for Copywriting","AI can help turn a clear brief into drafts for posts, emails, scripts, and product explanations. Strong prompts include audience, goal, facts, tone, constraints, and CTA. Edit the output to sound like you and to remain accurate.","Create a prompt that asks for three educational posts using facts you provide.","What improves AI copy? | A clear brief and human review | Less context | Unverified claims | More hype"],
["AI for Content Planning","AI can convert a topic list into a calendar, content pillars, repurposing plan, and weekly workflow. Keep the plan realistic. A smaller schedule that you execute is better than a huge plan you abandon.","Build a seven-day content plan with AI and then edit it to fit your real schedule.","What makes a plan useful? | It can actually be executed | It has the most posts | It uses every platform | It promises virality"],
["Simple Design and Workflow","Use simple design principles: one message, readable hierarchy, consistent branding, and a clear CTA. Create reusable templates for recurring content. Keep the design secondary to the message.","Create one reusable AVN-style educational post template.","What should design support? | The message and user action | Confusion | Excessive decoration | Unverified claims"],
["Tracking and Measurement Tools","Track meaningful numbers such as content reach, link clicks, leads, conversion rate, refunds, and revenue where your systems permit. Avoid vanity metrics becoming the only goal.","Create a simple weekly tracking sheet with five metrics that matter to your funnel.","Which is closer to a business metric? | Qualified conversions | Likes alone | Follower count alone | Emoji count"],
["Build Your AI Workflow","A useful workflow is Research → Verify → Brief → Generate → Edit → Compliance Check → Publish → Measure → Improve. AI can accelerate the process, but it does not remove responsibility or guarantee performance.","Document your own repeatable AI workflow in nine steps.","Where should verification happen? | Before publishing important claims | Never | Only after complaints | Only when sales fall"],
]],
["E. Conversion Basics", [
["What Conversion Means","A conversion is the desired action in your funnel, such as a qualified lead, signup, purchase, or other program-defined action. Conversion rate helps you understand how efficiently relevant traffic produces that action.","Define the primary conversion for your current affiliate offer.","What is a conversion? | A defined desired action | Any impression | Any follower | A guaranteed sale"],
["Trust Before the Sale","People are more likely to act when they understand the offer and trust the source. Trust comes from accuracy, clarity, relevant proof, transparent limitations, and consistent value—not pressure.","List five things you can do to make a product recommendation more trustworthy.","What creates durable trust? | Accuracy and transparency | Pressure | Fake proof | Hidden conditions"],
["Understanding Buyer Intent","Not everyone who sees your content is ready to buy. Some are learning, some are comparing, and some are ready to act. Match the message and CTA to the stage instead of pushing the same offer to everyone.","Create one message for each stage: learning, comparing, ready.","Why identify buyer intent? | To match the message to readiness | To pressure beginners | To hide prices | To avoid education"],
["Better Calls to Action","Effective CTAs are specific, honest, and connected to the content. Examples include learn more, compare options, view the full guide, or check the current offer. Avoid fake urgency and guaranteed-income language.","Write five CTAs for one offer, from soft to direct.","A good CTA should be… | Clear and relevant | Misleading | Hidden | Unrelated"],
["Landing Pages and Offer Pages","A landing page should quickly explain who the offer is for, the problem it addresses, key benefits, important conditions, and the next step. Remove unnecessary distractions and make the destination consistent with the promise in the promotion.","Outline a simple landing page with headline, problem, benefits, proof, FAQ, CTA, and disclosure.","What should a landing page match? | The promise made in the promotion | A random message | A different product | A hidden condition"],
["Follow-Up","Follow-up helps people who need more information before acting. Use useful reminders, FAQs, demonstrations, comparisons, and answers to objections. Respect consent and platform rules; do not spam.","Create a three-message follow-up sequence that teaches before asking again.","What should follow-up provide? | Useful additional information | Repeated pressure | Fake scarcity | Unwanted spam"],
["Handling Questions and Objections","Common objections include price, trust, relevance, timing, and uncertainty. Respond with facts, clarify what the product does and does not do, and allow people to decide. Never invent evidence to overcome an objection.","List five likely objections and write an honest response to each.","How should objections be handled? | With accurate information and respect | With deception | With pressure | With fake testimonials"],
["Conversion Review","When results are weak, review the funnel: audience fit, content quality, traffic quality, offer relevance, page clarity, CTA, and follow-up. Change one meaningful variable at a time when possible so you can learn what helped.","Choose one funnel stage to improve this week and define the metric you will watch.","What is a useful optimization approach? | Measure, change, and compare | Change everything at once | Guess forever | Hide results"],
]],
["F. Execution & Consistency", [
["Build a Weekly Operating Plan","Turn your strategy into recurring actions: research, create, publish, engage, follow up, review metrics, and learn. Schedule actions around your real availability.","Create a weekly timetable with specific days and times for your core activities.","What makes an operating plan realistic? | It fits your actual time and resources | It contains unlimited tasks | It depends on motivation only | It has no measurement"],
["Daily Affiliate Activities","A focused daily routine can include one content action, one audience action, one follow-up action, and one learning or measurement action. The exact schedule should match your stage and capacity.","Design a 60-minute daily routine for the next seven days.","What matters more than doing everything? | Consistently executing the right priorities | Constantly changing strategy | Posting randomly | Buying more tools"],
["Content → Traffic → Conversion","Connect your activities. Content creates attention; traffic brings relevant people to the next step; conversion measures whether the offer and funnel work. If one stage is weak, diagnose it rather than blaming the entire business.","Write one metric and one improvement action for each stage.","Why map the stages? | To diagnose where performance changes | To guarantee sales | To avoid tracking | To make the process mysterious"],
["Track What Matters","Review content reach, qualified clicks, leads, conversion rate, revenue, refunds, and other relevant metrics. Look for trends rather than reacting emotionally to one post.","Make a weekly scorecard and record your numbers for four weeks.","Why review trends? | One result may not represent the whole system | Numbers never matter | One viral post proves everything | Tracking is only for experts"],
["Learn From Results","A result is information. Ask what happened, what you expected, what changed, and what you will test next. Keep a simple experiment log so lessons compound over time.","Write one experiment: hypothesis, change, metric, time period, and result.","What is the purpose of an experiment log? | To learn systematically | To hide poor results | To guarantee success | To avoid testing"],
["Build Your Personal Brand","A personal brand is the consistent experience people associate with your name: what you teach, how you communicate, what you stand for, and the quality of your help. Build credibility through useful work, not exaggerated status claims.","Write your three brand pillars and one sentence describing what you help people do.","What strengthens a personal brand? | Consistent useful value | Fake authority | Manufactured testimonials | Constant hype"],
["The 30-Day Execution Challenge","For 30 days, choose one audience, one core offer, one primary channel, and a realistic publishing schedule. Track actions and outcomes. Review weekly and make controlled improvements.","Create your 30-day plan with weekly targets for content, audience activity, follow-up, and measurement.","What should a 30-day challenge optimize for? | Consistent learning and execution | Instant guaranteed income | Maximum posting volume | Avoiding measurement"],
["Final AVN Action Plan","Bring everything together: niche, audience, offer, content pillars, channel, funnel, tools, metrics, weekly schedule, and next experiment. Your goal is a repeatable system you can improve—not a promise of overnight results.","Submit your one-page AVN Action Plan covering all nine areas.","What is the strongest final mindset? | Build, measure, learn, improve | Expect guaranteed income | Copy others blindly | Stop after the first setback"],
]]
]

// Seed the built-in AVN courses before lessons.
const count = db.prepare("SELECT COUNT(*) c FROM courses").get().c;
if (!count) {
  const add = db.prepare("INSERT INTO courses(name,description,price) VALUES(?,?,?)");
  add.run("Affiliate Marketing Training","Practical foundation for affiliate marketing, promotion, AI tools, conversion and consistent execution.",600000);
  add.run("AIM Course","A structured deeper course for affiliate marketing and digital skills.",2000000);
}

// Seed the complete 48-lesson curriculum into the Affiliate Marketing Training course.
if (db.prepare("SELECT COUNT(*) c FROM lessons").get().c == 0) {
    const course_id = db.prepare("SELECT id FROM courses ORDER BY id LIMIT 1").get().id;
    const ins=db.prepare("INSERT INTO lessons(course_id,title,content,position,module,assignment,quiz) VALUES(?,?,?,?,?,?,?)");
    let pos=1;
    for (const [module, lessons] of curriculum) {
        for (const [title,content,assignment,quiz] of lessons) {
            ins.run(course_id,title,content,pos,module,assignment,quiz); pos++;
        }
    }
}

const adminEmail = process.env.ADMIN_EMAIL;
const adminPass = process.env.ADMIN_PASSWORD;
if (adminEmail && adminPass) {
  const exists = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail.toLowerCase());
  if (!exists) {
    db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
      .run("AVN Admin", adminEmail.toLowerCase(), bcrypt.hashSync(adminPass, 12), "admin");
  }
}

function token(user){ return jwt.sign({id:user.id,role:user.role}, JWT_SECRET,{expiresIn:"7d"}); }
function auth(req,res,next){
  try {
    const raw=(req.headers.authorization||"").replace("Bearer ","");
    const data=jwt.verify(raw,JWT_SECRET);
    req.user=db.prepare("SELECT id,name,email,phone,role FROM users WHERE id=?").get(data.id);
    if(!req.user) throw Error();
    next();
  } catch { res.status(401).json({error:"Please log in."}); }
}
function admin(req,res,next){ if(req.user.role!=="admin") return res.status(403).json({error:"Admin only."}); next(); }

app.get("/api/courses",(req,res)=>res.json(db.prepare("SELECT id,name,description,price FROM courses").all()));

app.post("/api/register",(req,res)=>{
  const {name,email,phone,password}=req.body;
  if(!name||!email||!password||password.length<6) return res.status(400).json({error:"Name, email and a password of at least 6 characters are required."});
  try{
    const result=db.prepare("INSERT INTO users(name,email,phone,password_hash) VALUES(?,?,?,?)")
      .run(name.trim(),email.trim().toLowerCase(),phone||"",bcrypt.hashSync(password,12));
    const user={id:result.lastInsertRowid,role:"student"};
    res.json({token:token(user),message:"Account created."});
  }catch(e){res.status(400).json({error:"That email is already registered."});}
});

app.post("/api/login",(req,res)=>{
  const u=db.prepare("SELECT * FROM users WHERE email=?").get((req.body.email||"").trim().toLowerCase());
  if(!u||!bcrypt.compareSync(req.body.password||"",u.password_hash)) return res.status(401).json({error:"Invalid email or password."});
  res.json({token:token(u),user:{name:u.name,email:u.email,role:u.role}});
});

app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/my-courses",auth,(req,res)=>{
  res.json(db.prepare(`
    SELECT c.id,c.name,c.description,c.price,p.status,p.reference
    FROM purchases p JOIN courses c ON c.id=p.course_id
    WHERE p.user_id=? AND p.status='success'
  `).all(req.user.id));
});

app.post("/api/payments/manual",auth,(req,res)=>{
  const course=db.prepare("SELECT * FROM courses WHERE id=?").get(req.body.courseId);
  const reference=(req.body.reference||"").trim();
  if(!course) return res.status(404).json({error:"Course not found."});
  if(!reference) return res.status(400).json({error:"Enter your OPay transaction/reference number."});
  if(db.prepare("SELECT id FROM purchases WHERE reference=?").get(reference))
    return res.status(400).json({error:"That transaction reference has already been submitted."});
  db.prepare("INSERT INTO purchases(user_id,course_id,reference,status,amount) VALUES(?,?,?,?,?)")
    .run(req.user.id,course.id,reference,"pending",course.price);
  res.json({message:"Payment submitted for manual verification."});
});
app.get("/api/payments/status/:reference",auth,(req,res)=>{
  const p=db.prepare("SELECT status FROM purchases WHERE reference=? AND user_id=?").get(req.params.reference,req.user.id);
  if(!p) return res.status(404).json({error:"Payment not found."});
  res.json({status:p.status});
});
app.get("/api/admin/pending-payments",auth,admin,(req,res)=>res.json(db.prepare(`
SELECT p.id,p.reference,p.amount,p.status,p.created_at,u.name,u.email,u.phone,c.name course
FROM purchases p JOIN users u ON u.id=p.user_id JOIN courses c ON c.id=p.course_id
WHERE p.status='pending' ORDER BY p.id DESC`).all()));
app.post("/api/admin/payments/:id/approve",auth,admin,(req,res)=>{
  const p=db.prepare("SELECT * FROM purchases WHERE id=?").get(req.params.id);
  if(!p) return res.status(404).json({error:"Payment not found."});
  db.prepare("UPDATE purchases SET status='success' WHERE id=?").run(p.id);
  res.json({message:"Payment approved and course access granted."});
});
app.post("/api/admin/payments/:id/reject",auth,admin,(req,res)=>{
  const p=db.prepare("SELECT * FROM purchases WHERE id=?").get(req.params.id);
  if(!p) return res.status(404).json({error:"Payment not found."});
  db.prepare("UPDATE purchases SET status='failed' WHERE id=?").run(p.id);
  res.json({message:"Payment rejected."});
});


function hasCourseAccess(userId, courseId, role){
  if(role==="admin") return true;
  return !!db.prepare("SELECT id FROM purchases WHERE user_id=? AND course_id=? AND status='success'").get(userId,courseId);
}
app.get("/api/courses/:id/curriculum",auth,(req,res)=>{
  const course=db.prepare("SELECT id,name,description,price FROM courses WHERE id=?").get(req.params.id);
  if(!course) return res.status(404).json({error:"Course not found."});
  if(!hasCourseAccess(req.user.id,course.id,req.user.role)) return res.status(403).json({error:"Complete payment and wait for approval before accessing this training."});
  const lessons=db.prepare("SELECT id,title,content,position,module,assignment,quiz FROM lessons WHERE course_id=? ORDER BY position").all(course.id);
  res.json({course,lessons});
});
app.get("/api/lessons/:id",auth,(req,res)=>{
  const lesson=db.prepare("SELECT id,course_id,title,content,position,module,assignment,quiz FROM lessons WHERE id=?").get(req.params.id);
  if(!lesson) return res.status(404).json({error:"Lesson not found."});
  if(!hasCourseAccess(req.user.id,lesson.course_id,req.user.role)) return res.status(403).json({error:"Course access required."});
  res.json(lesson);
});
app.get("/api/admin/stats",auth,admin,(req,res)=>{
  const users=db.prepare("SELECT COUNT(*) c FROM users WHERE role='student'").get().c;
  const sales=db.prepare("SELECT COUNT(*) c FROM purchases WHERE status='success'").get().c;
  const revenue=db.prepare("SELECT COALESCE(SUM(amount),0) n FROM purchases WHERE status='success'").get().n;
  res.json({users,sales,revenue});
});
app.get("/api/admin/users",auth,admin,(req,res)=>res.json(db.prepare("SELECT id,name,email,phone,role,created_at FROM users ORDER BY id DESC").all()));
app.get("/api/admin/purchases",auth,admin,(req,res)=>res.json(db.prepare(`
SELECT p.id,p.reference,p.amount,p.status,p.created_at,u.name,u.email,c.name course
FROM purchases p JOIN users u ON u.id=p.user_id JOIN courses c ON c.id=p.course_id ORDER BY p.id DESC`).all()));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log("AVN running on http://localhost:"+PORT));
